int dummy_func() {
    return 42;
}
