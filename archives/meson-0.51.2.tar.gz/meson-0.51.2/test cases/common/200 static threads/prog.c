extern void *g(void);

int main(void) {
  g();
  return 0;
}
