#include"subbie.h"

int main(int argc, char **argv) {
    return subbie();
}
