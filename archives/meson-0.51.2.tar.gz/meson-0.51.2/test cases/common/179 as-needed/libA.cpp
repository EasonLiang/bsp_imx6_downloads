#define BUILDING_DLL

#include "libA.h"

namespace meson_test_as_needed {
  DLL_PUBLIC bool linked = false;
}
