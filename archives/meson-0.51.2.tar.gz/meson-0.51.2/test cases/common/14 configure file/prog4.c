#include <config4a.h>
#include <config4b.h>

int main(int argc, char **argv) {
    return RESULTA + RESULTB;
}
