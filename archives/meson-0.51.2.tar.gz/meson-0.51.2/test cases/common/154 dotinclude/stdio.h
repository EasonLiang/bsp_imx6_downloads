// There is no #pragma once because we _want_ to cause an eternal loop
// if this wrapper invokes itself.

#define WRAPPER_INCLUDED

#include<stdio.h>
