// No includes here, they need to come from the PCH

int main(int argc, char **argv) {
    return FOO + BAR;
}

