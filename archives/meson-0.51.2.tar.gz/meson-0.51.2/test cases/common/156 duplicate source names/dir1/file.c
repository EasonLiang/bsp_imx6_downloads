extern int dir2;
extern int dir2_dir1;
extern int dir3;
extern int dir3_dir1;

int main() {
    if (dir2 != 20)
        return 1;
    if (dir2_dir1 != 21)
        return 1;
    if (dir3 != 30)
        return 1;
    if (dir3_dir1 != 31)
        return 1;
    return 0;
}
